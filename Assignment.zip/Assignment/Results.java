package AssignmentTest;

import java.io.File;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class Results extends Readfile {
	String file;
	int match;
	List files;
	List<Integer> matches;
	Results[] myResults;
	int i;
	
	//constructor
	public Results( String file,int match,List files, String cs1,int i ,int match1,List<Integer> matches)
	{
		super(files,cs1,i,match1, matches);
		this.file = file;
		this.match = match;
		this.matches = matches;
		this.files = files;
	}
	//files
	public void setFile(String file)
	{
		this.file = file;
	}
	public String getFile(String file)
	{
		return file;
	}
	//matches
	public void setMatches(int match)
	{
		this.match = match;
	}
	public int getMatches(int match)
	{
		return match;
	}{
	
	for( i = 0; i < files.size(); i++)
	{
		myResults[0].file = (String) files.get(i);
		myResults[0].match = matches.get(i);
		
		myResults[1].file = (String) files.get(i);
		myResults[1].match = matches.get(i);
	
		myResults[2].file = (String) files.get(i);
		myResults[2].match = matches.get(i);
	}
	
	
	//sorts the class with most matches at the top
	Arrays.sort(myResults,
            new Comparator<Results>()
            {
                public int compare(Results o1, Results o2)
                {
                    if (o1.match == o2.match)
                    {
                        return 0;
                    }
                    else if (o1.match < o2.match)
                    {
                        return -1;
                    }
                    return 1;
                }
            });
	
	public String toString () {
		return "Files in sorted oreder" + this.myResults;
	}
}}
