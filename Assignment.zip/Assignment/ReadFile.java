package AssignmentTest;

import java.io.File;

//Program searches for phrases, if key word is eg. walk, walking,walked will be recorded as a match.

import java.lang.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ReadFile {
	List files;
	String cs1;
	int i ;
	int match = 0;
	List<Integer> matches = new ArrayList();		

	//constructor
	public ReadFile(String cs1, List files)
	{
		this.cs1 = cs1;
		this.files = files;
		this.i = i;
		this.match = match;
		this.matches = matches;

	


	try {
	//Create file instance
		
			for (i=0; i < files.size(); i++)
			{
				java.io.File file = new java.io.File((String) files.get(i));
				Scanner input = new Scanner(file); 
				match =0;
	  
	   
			   while(input.hasNext())
				{
				String str = input.next();   
			   
			   // string contains the specified sequence of char values
				  boolean retval = str.contains(cs1);
				   if (retval != false)
				   {
					   match +=1;
					   
				   }
				   
				}//END WHILE
				
			   //if match occurs, print results	
			   if ( match > 0)
			   {
			   System.out.println( file + "     Search complete, Total matches:" + match);
			   
			   }
			   
			   //adds match to array for sorting.
			   matches.add(match);
			   
			   //close scanners
			   input.close();
			}//end for
	}//end try

	
	
		
	catch (Exception e)
	{
		e.printStackTrace();
	}
}
	
	//keyword
	public void setKey(String cs1)
	{
		this.cs1 = cs1;
	}
	public String getName(String cs1)
	{
		return cs1;
	}
	//files
	public void setFiles(List files)
	{
		this.files = files;
	}
	public List getFiles(List files)
	{
		return files;
	}
	//counter
	public void setCounter(int i )
	{
		this.i = i;
	}
	public int getCounter(int i)
	{
		return i;
	}
	//matches
	public void setMatch(int match)
	{
		this.match = match;
	}
	public int getMatch(int match)
	{
		return match;
	}
	public void setMatches(List matches)
	{
		this.matches = matches;
	}
	public List getMatches(List matches)
	{
		return matches;
	}
	
}//end Readfile